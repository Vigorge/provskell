module Main where

import TRS
import System.Environment   
import Data.Aeson

main :: IO ()
main = do  
    (arg:_) <- getArgs
    putStrLn $ show $ processTRS arg
