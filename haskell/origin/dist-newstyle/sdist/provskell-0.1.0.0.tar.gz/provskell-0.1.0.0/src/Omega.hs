module Omega(Omega(), w, (^)) where

import Data.List
import Prelude hiding (exponent,(^))

-- Implementation for ordinals in [0,epsilon0)
-- in Cantor Normal Form (CNF)

data Term = Term { exponent :: Omega, multiplicity :: Integer } 
  deriving Eq
  
newtype Omega = CNFPowerSum [Term] 
  deriving Eq

zero :: Omega
zero = CNFPowerSum []

w :: Omega -> Omega
w a = CNFPowerSum [Term a 1]

nat :: Integer -> Omega
nat k 
    | k > 0  = CNFPowerSum [Term zero k]
    | k == 0 = zero
    | k < 0  = error "There are no negative ordinals"

-- Order relation
infixr 0 `orElse`
orElse :: Ordering -> Ordering -> Ordering
c1 `orElse` c2 = if c1 /= EQ then c1 else c2

cnfCompare :: Omega -> Omega -> Ordering
cnfCompare (CNFPowerSum ds) (CNFPowerSum es) = 
    case (ds, es) of
        ([], []) -> EQ
        ([],  _) -> LT
        (_ , []) -> GT
        (d:dt,e:et) ->
                    (exponent d `cnfCompare` exponent e)
          `orElse` (multiplicity d `compare` multiplicity e)
          `orElse` (CNFPowerSum dt `cnfCompare` CNFPowerSum et)

-- Omega addition
cnfSum :: Omega -> Omega -> Omega
cnfSum alpha (CNFPowerSum []) = alpha
cnfSum (CNFPowerSum ds) (CNFPowerSum (t:ts)) = 
    -- break off the part that will be absorbed/increased in multiplicity
    let (hi,lo) = break (\d -> exponent d <= exponent t) ds in
    -- Is the exponent of t already present (first term of lo-part)
    case lo of
        []  -> CNFPowerSum (hi ++ (t:ts))
        e:_ -> 
          if exponent e == exponent t
              then CNFPowerSum (hi ++ (t { multiplicity = multiplicity e + multiplicity t }) : ts)
              else CNFPowerSum (hi ++ (t:ts))
              
-- Omega multiplication
cnfMultByTerm :: Omega -> Term -> Omega
cnfMultByTerm (CNFPowerSum[]) t = 0
cnfMultByTerm (CNFPowerSum (d:ds)) (Term (CNFPowerSum[]) n) = 
    CNFPowerSum ((d { multiplicity = multiplicity d * n }):ds)
cnfMultByTerm (CNFPowerSum (d:ds)) (Term b n) = 
    CNFPowerSum [d { exponent = exponent d + b, multiplicity = n }]

cnfMult :: Omega -> Omega -> Omega
cnfMult alpha (CNFPowerSum ts) = sum [ cnfMultByTerm alpha t | t <- ts ]

-- Omega exponentation

-- Helpers
isFinite :: Omega -> Bool
isFinite (CNFPowerSum[]) = True
isFinite (CNFPowerSum [Term (CNFPowerSum[]) n]) = True
isFinite   _ = False

getFinite :: Omega -> Integer 
getFinite (CNFPowerSum[]) = 0
getFinite (CNFPowerSum [Term (CNFPowerSum[]) n]) = n
getFinite _ = error "No finite ordinal given"

-- Finite powers via repeated squaring
-- TODO there is a faster, more explicit solution

dlog2 n p b 
    | p >= n = (p,b)
    | otherwise = dlog2 n (2*p) (b+1)

base2 n = let (p,b) = dlog2 n 1 0 in base2rec n p 
    where 
        base2rec n 0 = []
        base2rec n p 
            | n < p = 0 : base2rec n (p `div` 2)
            | otherwise = 1 : base2rec (n - p) (p `div` 2)

powerRec :: a -> a -> (a -> a -> a) -> [Int] -> a
powerRec acc p op [] = acc
powerRec acc p op (0:bits) = powerRec acc (p `op` p) op bits
powerRec acc p op (1:bits) = powerRec (acc `op` p) (p `op` p) op bits
            
finitePow :: Omega -> Integer -> Omega
finitePow a 0 = 1
finitePow a n = 
    powerRec 1 a (*) (reverse $ base2 n)    

-- Arbitrary powers
    
cnfExpByW :: Omega -> Omega -> Omega
cnfExpByW (CNFPowerSum []) b = 0
cnfExpByW a 0 = a
cnfExpByW a@(CNFPowerSum (Term b1 c1:bs)) b 
    | a == 1 = 1
    | a < w 1 && isFinite b = w (w (fromInteger (getFinite b - 1)))
    | a < w 1 && otherwise = w (w b)
    | otherwise = w (b1 * w b)
    
cnfExpByTerm :: Omega -> Term -> Omega
cnfExpByTerm a (Term b c) = finitePow (cnfExpByW a b) c

(^) :: Omega -> Omega -> Omega
a^(CNFPowerSum terms) = product [ cnfExpByTerm a t | t <- terms ]

-- Instances    
instance Num Omega where 
    a + b = cnfSum a b
    a * b = cnfMult a b
    fromInteger = nat
    
    negate = undefined
    abs = undefined
    signum = undefined

instance Ord Omega where
    compare = cnfCompare

-- Pretty printing

showT :: Term -> String
showT (Term (CNFPowerSum[]) n) = show n
showT (Term (CNFPowerSum [Term (CNFPowerSum[]) 1]) 1) = "w"
showT (Term (CNFPowerSum [Term (CNFPowerSum [Term (CNFPowerSum[]) 1]) 1]) 1) = "w^w"
showT (Term (CNFPowerSum [Term (CNFPowerSum[]) n]) 1) = "w^" ++ show n
showT (Term (CNFPowerSum [Term (CNFPowerSum[]) 1]) k) = "w*" ++ show k
showT (Term (CNFPowerSum [Term (CNFPowerSum[]) n]) k) = "w^" ++ show n ++ "*" ++ show k
showT (Term a 1) = "w^(" ++ showCNF a ++ ")"
showT (Term a n) = "w^(" ++ showCNF a ++ ")*" ++ show n

showCNF :: Omega -> String
showCNF (CNFPowerSum[]) = "0"
showCNF (CNFPowerSum terms) = 
    intercalate " + " [
        showT t | t <- terms
      ]

instance Show Omega where
    show = showCNF