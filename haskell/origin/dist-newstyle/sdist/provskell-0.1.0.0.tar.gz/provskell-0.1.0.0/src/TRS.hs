module TRS
    ( processTRS
    ) where

import Data.Text as T hiding (tail, map, head, null)
import Prelude hiding (lookup)

import Data.Map.Strict hiding (null, map)
import qualified Data.Map.Strict as Map
import Text.TeXMath.Readers.TeX
import Text.TeXMath.Types as TXT
import Data.Either
import Data.String
import Data.ByteString.Lazy.Char8 as BS hiding (tail, map, head, null)
import Data.Aeson as JSON
import GHC.Generics

data Output =
  Output { errors :: String
         , funcs  :: Map String Int
  }
instance ToJSON Output where
  toJSON (Output errors funcs) =
    object [ "errors" .= errors
           , "funcs"  .= funcs
    ]

data Func = C String
          | F String Func
          | P
          | ErF String
instance Show Func where
  show (ErF er) = er
  show P = "x"
  show (C b) = b
  show (F a f) = a ++ "(" ++ show f ++ ")"

arity :: Func -> Int
arity (C _) = 0
arity (F _ _) = 1

name :: Func -> String
name (C n) = n
name (F n _) = n
name _ = ""

data Rule = Rl Func Func
instance Show Rule where
  show (Rl f1 f2) = show f1 ++ "=" ++ show f2

formOutput :: ([Either String Rule], Map String Int) -> ByteString
formOutput (trs, fs) = JSON.encode $ Output (getErrors 1 trs) fs
  where
    getErrors :: Int -> [Either String Rule] -> String
    getErrors n [] = ""
    getErrors n (r:rs) =
      case r of
        Left er -> show n ++ ": " ++ er ++ "\n" ++ getErrors (n + 1) rs
        Right _ -> getErrors (n + 1) rs

processTRS :: String -> ([Either String Rule], Map String Int)
processTRS str = formRules $ fromRight [ENumber "0"] $ readTeX $ T.pack str

formRules :: [TXT.Exp] -> ([Either String Rule], Map String Int)
formRules ts =
  let (t':ts', trs, fs) = rules ts Map.empty
  in
    case t' of
      ESymbol Ord "!" -> (trs, fs)
      _ -> error $ "Incorrect syntax: " ++ show ts'
  where
    rules :: [TXT.Exp] -> Map String Int -> ([TXT.Exp], [Either String Rule], Map String Int)
    rules (t:ts) fs =
        case t of
          TXT.EIdentifier _ ->
            let (ts', rl, fs') = rule (t:ts) fs
            in let (ts'', rls, fs'') = rules ts' fs'
              in case rl of
                Left er -> (ts'', Left er : rls, fs'')
                _ -> (ts'', rl : rls, fs'')
          ESymbol Pun ";" -> rules ts fs
          _   -> (t:ts, [], fs)

    rule :: [TXT.Exp] -> Map String Int -> ([TXT.Exp], Either String Rule, Map String Int)
    rule ts fs =
      let (t':ts', lhs, fs') = function ts fs
      in
        case lhs of
          ErF er -> (toNextRule ts, Left er, fs')
          _ -> case t' of
            TXT.ESymbol Rel "=" ->
              let (ts'', rhs, fs'') = function ts' fs'
              in case head ts'' of
                ESymbol Pun ";" -> (tail ts'', Right (Rl lhs rhs), fs'')
                _ -> (toNextRule ts, Left (show $ head ts''), fs'')
            _ -> (toNextRule ts', Left (show t'), fs')

    function :: [TXT.Exp] -> Map String Int -> ([TXT.Exp], Func, Map String Int)
    function (t1:ts) fs =
      case t1 of
        TXT.EIdentifier a ->
          if a /= "x"
          then case head ts of
            EDelimited "(" ")" ts' -> let (_, func, fs') = function' (map (fromRight (ENumber "0")) ts') fs
              in
                case func of
                  ErF er -> (ts, ErF er, fs')
                  _ -> (tail ts, checkFunc (F (T.unpack a) func) fs', Map.insert (T.unpack a) 1 fs')
            _ -> (ts, checkFunc (C (T.unpack a)) fs, Map.insert (T.unpack a) 0 fs)
          else (t1:ts, ErF (show t1), fs)
        _ -> (t1:ts, ErF (show t1), fs)

    function' :: [TXT.Exp] -> Map String Int -> ([TXT.Exp], Func, Map String Int)
    function' (t1:ts) fs =
      case t1 of
        TXT.EIdentifier a ->
          if a /= "x"
          then if null ts
            then (ts, checkFunc (C (T.unpack a)) fs, Map.insert (T.unpack a) 0 fs)
            else case head ts of
              EDelimited "(" ")" ts' -> let (_, func, fs') = function' (map (fromRight (ENumber "0")) ts') fs
                in
                  case func of
                    ErF er -> (ts, ErF er, fs')
                    _ -> (ts, checkFunc (F (T.unpack a) func) fs', Map.insert (T.unpack a) 1 fs')
              _ -> (ts, ErF (show t1), fs)
          else (ts, P, fs)
        _ -> (ts, ErF (show t1), fs)

    checkFunc :: Func -> Map String Int -> Func
    checkFunc f m =
      case Map.lookup (name f) m of
        Nothing -> f
        Just ar ->
          if ar == arity f
          then f
          else ErF (name f ++ " has different arity in other rules")

    toNextRule :: [TXT.Exp] -> [TXT.Exp]
    toNextRule ts
      | head ts == ESymbol Pun ";" = tail ts
      | otherwise = toNextRule $ tail ts
